<?php
require_once('../../private/initialize.php');
$page_title = 'Bird: Member Menu'; 
include(SHARED_PATH . '/member-header.php'); 
// require_login();
?>

<!-- <h2>Main Menu</h2> -->

<?php include(SHARED_PATH . '/footer.php'); ?>