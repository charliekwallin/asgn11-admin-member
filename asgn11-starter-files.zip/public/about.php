<?php 
require_once('../private/initialize.php'); 
$page_title = 'About Us'; 
include(SHARED_PATH . '/header.php'); 
?>

    <h2>About Us</h2>
    <p> Cupcake ipsum dolor sit amet jujubes jelly-o. Dessert chupa chups donut cake fruitcake ice cream bear claw. Dragée chocolate icing lemon drops fruitcake sesame snaps candy canes. Lemon drops halvah lemon drops cake muffin marshmallow shortbread.
</p>
    <p> Halvah marzipan danish sweet roll marshmallow. Candy gummi bears cookie candy apple pie halvah lollipop. Bonbon tart toffee chocolate pudding tiramisu liquorice ice cream.</p>

<?php include(SHARED_PATH . '/footer.php'); ?>
