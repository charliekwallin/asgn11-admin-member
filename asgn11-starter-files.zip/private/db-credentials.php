<?php

// local
define("DB_SERVER", "localhost");
define("DB_USER", "doall");
define("DB_PASS", "MAGNIFY-gyro-almond-brickbat");
define("DB_NAME", "bird");

//webhost
// define("DB_SERVER", "localhost");
// define("DB_USER", "charli12_birduser");
// define("DB_PASS", "iMh64HjCnwr8erWUaz6");
// define("DB_NAME", "charli12_bird");