<footer>
  &copy; <?= date('Y'); ?> <p>NC Birds - Special thanks to the Cornell University Bird Lab</p>

</footer>

</body>
</html>

<?php db_disconnect($database); ?>